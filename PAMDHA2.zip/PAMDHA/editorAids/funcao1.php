<?php
function conecta1(){

$usuario="root";
$senha="";
$banco="pamdha";
$server="localhost";
 // $usuario="shemaysr";
  //$senha="sandro7";
  //$banco="shemaysr_igreja";
  $db=mysql_connect($server,$usuario,$senha)  or die ('Erro ao abrir Banco de Dados: ' . mysql_error());
  mysql_select_db($banco,$db);
  return $db;
 }
 
 function get_ext($file){
return pathinfo($file,PATHINFO_EXTENSION);}

 function retira_espaco($frase){
 $palavra=explode(" ",$frase);
 $frase1=" ";
 foreach($palavra as $pal){
  if($pal=="de" or $pal=="De" or $pal=="DE" or $pal=="dE" or $pal=="da" or $pal=="dA"  or $pal=="Da" or $pal=="DA" or
  $pal== "-" or $pal=="." or $pal=="do" or $pal=="Do" or $pal=="DO" or $pal=="." or $pal=="[" or $pal=="]" or $pal=="(" or $pal==")"){
   $pal=" ";
  }
  $frase1=$frase1.$pal;
  }
  $nome=" ";
  $tam=strlen($frase1);
  for($i=0;$i<=$tam;$i++){
   $letra=substr($frase1,$i,1);
    if ($letra<>" "){
     $nome=$nome.$letra;
  }
  }
 return $nome;
 }
 ?>

