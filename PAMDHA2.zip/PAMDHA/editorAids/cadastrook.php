<html>
<h2 align=center> Noticia cadastrada com exito<h2>
<h2 Align=center><a href=editor.php>Voltar </a><h2>
<?php exit; ?>
</htmL>
