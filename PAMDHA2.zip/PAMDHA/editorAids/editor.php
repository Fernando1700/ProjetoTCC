<html>
<head>
<title>Editor de Texto JavaScript ::: Linha de C�digo</title>
<script language="JavaScript">
function Enviar(){
document.FormTextos.txtTexto.value = editor.document.body.innerHTML;
document.forms[0].action="editor.php?controle=1";
document.forms[0].submit();
}

 
	function Iniciar() {
		editor.document.designMode = 'On';
	}

	function recortar() {
		editor.document.execCommand('cut', false, null);
	}

	function copiar() {
		editor.document.execCommand('copy', false, null);
	}
	
	function colar() {
		editor.document.execCommand('paste', false, null);
	}

	function desfazer() {
		editor.document.execCommand('undo', false, null);
	}

	function refazer() {
		editor.document.execCommand('redo', false, null);
	}

	function negrito() {
		editor.document.execCommand('bold', false, null);
	}

	function italico() {
		editor.document.execCommand('italic', false, null);
	}

	function sublinhado() {
		editor.document.execCommand('underline', false, null);
	}

	function alinharEsquerda() {
		editor.document.execCommand('justifyfull', false, null);
	}

	function centralizado()	{
		editor.document.execCommand('justifycenter', false, null);
	}

	function alinharDireita() {
		editor.document.execCommand('justifyright', false, null);
	}

	function numeracao() {
		editor.document.execCommand('insertorderedlist', false, null);
	}

	function marcadores() {
		editor.document.execCommand('insertunorderedlist', false, null);
	}

	function fonte(fonte) {
		if(fonte != '')
			editor.document.execCommand('fontname', false, fonte);
	}

	function tamanho(tamanho) {
		if(tamanho != '')
			editor.document.execCommand('fontsize', false, tamanho);
	}

</script>
 <body onLoad="Iniciar()" bgcolor="#EFEDE1">
<table align="center" width="600px" height="30px" border="0" cellspacing="0" cellpadding="0" >	
<h1 align=center>Inclus�o de Noticias</h1>
	<tr>
	<td align="center">
    	<select name="fonte" onChange="fonte(this.options[this.selectedIndex].value)">
		<option value=""></option>
        <option value="Arial">Arial</option>
        <option value="Courier">Courier</option>
        <option value="Sans Serif">Sans Serif</option>
        <option value="Tahoma">Tahoma</option>
        <option value="Times New Roman">Times New Roman</option>
        <option value="Verdana">Verdana</option>
	</select>
	&nbsp;		
	<select name="tamanho" onChange="tamanho(this.options[this.selectedIndex].value)">
		<option value=""></option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
	</select>

	</td>

	<td align="center">
		
		<!-- Recortar -->
		<img src="img_editor/recortar.gif" onClick="recortar()" style="cursor:hand">
			
		<!-- Copiar -->
		<img src="img_editor/copiar.gif" onClick="copiar()" style="cursor:hand">
			
		<!-- Colar -->
		<img src="img_editor/colar.gif" onClick="colar()" style="cursor:hand">
			
		<!-- Desfazer --> 
		<img src="img_editor/desfazer.gif" onClick="desfazer()" style="cursor:hand">
			
		<!-- Refazer -->
		<img src="img_editor/refazer.gif" onClick="refazer()" style="cursor:hand">
			
		<!-- Negrito --> 
		<img src="img_editor/negrito.gif" onClick="negrito()" style="cursor:hand">
			
		<!-- It�lico -->
		<img src="img_editor/italico.gif" onClick="italico()" style="cursor:hand">
			
		<!-- Sublinhado -->
		<img src="img_editor/sublinhado.gif" onClick="sublinhado()" style="cursor:hand">
			
		<!-- Alinhar � Esquerda -->
		<img src="img_editor/alinhamentoesquerda.gif" onClick="alinharEsquerda();" style="cursor:hand">
			
		<!-- Alinhar ao Centro -->
		<img src="img_editor/centralizado.gif" onClick="centralizado()" style="cursor:hand">
			
		<!-- Alinha � Direita -->
		<img src="img_editor/alinhamentodireita.gif" onClick="alinharDireita()" style="cursor:hand">
			
		<!-- Numera��o -->
		<img src="img_editor/numeracao.gif" onClick="numeracao()" style="cursor:hand">

		<!-- Marcadores -->
		<img src="img_editor/marcador.gif" onClick="marcadores()" style="cursor:hand">
	
	</td>
	</tr>
	</table>

	<center>
        <iframe id="editor" name="editor" frameborder="1" style="border:1px solid; width: 80%; height:550px">
        </iframe>

       <form name="FormTextos" method="Post" action="">
     <div align="center">
      <p>
    <input type="hidden" name="txtTexto" id="txtTexto">
 <input type="button" value="Visualizar" onClick="Enviar()">
   </form>


	<br><br>
	<?php
	include "funcao1.php";
   $db=conecta1();
   if(isset($_POST["txtTexto"])){
   $texto = stripslashes($_POST["txtTexto"]);
   $horario = date(" Y-m-d H:i:s");
   $dia=substr($horario,9,2);
   $mes=substr($horario,6,2);
   $ano=substr($horario,1,4);
   $hora=substr($horario,12,2);
   $minuto=substr($horario,15,2);
   echo "<p align=center>";
   echo "<form method=post action=atualiza_noticia.php enctype=multipart/form-data>";
   $texto=stripslashes($texto);
   echo "<input type=hidden name=texto value='$texto'>";
   echo "<input type=hidden name=controle value=1>";
   echo "<table border=1 align=center width=100%>";
   echo "<tr><td>", $texto,"</td></tr>";
   echo "<table border=1 align=center>";
   echo "<tr><td><br>";
   echo "Foto 1: <input type=file name=arquivo[] size=50>";
   echo "</td></tr>";
   echo "<tr><td><br>";
   echo "Foto 2 :<input type=file name=arquivo[] size=50>";
   echo "</td></tr>";
   echo "<tr><td><br>";
   echo "Foto 3:<input type=file name=arquivo[] size=50>";
   echo "</td></tr>";
   echo "<tr><td><br>";
   echo "Foto 4:<input type=file name=arquivo[] size=50>";
   echo "</td></tr>";
   echo "<tr><td><br>";
   echo "Foto 5: <input type=file name=arquivo[] size=50>";
   echo "</td></tr>";
   echo "<tr><td><br>";
   echo "Foto 6: <input type=file name=arquivo[] size=50>";
   echo "<tr><td><br>";
   echo "<input type=submit value= Enviar>";
   echo "<tr><td><br>";
   echo "</form>";
   echo "</table>";
}
?> 
</center>

</body>

</html>
