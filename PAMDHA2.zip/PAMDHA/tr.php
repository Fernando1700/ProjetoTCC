<?php
include("conexaobanco.php");
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> PAMDHA - Teste Rápido</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="pamdha1.css" rel="stylesheet">
    <link rel="stylesheet" href="/js/vegas/vegas.min.css">
      <link rel="shortcut icon" href="icon.ico" >
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   <h4>  <center> <a href="index.php"><img class="img-responsive" title="PAMDHA" src="logopamdha.png"/> </a> </center> <h4>
    
    <nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
      
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
     <li> <a href="index.php" > PAMDHA </a>
      <li><a href="dstprot.php">Infecções Sexualmente Transmissiveis e Proteção</a></li>
      <li class="active"><a href="tr.php">Testes Rápidos</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">DST´s <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a id="linkmenu" href="hiv.php">HIV</a></li>
          <li><a id="linkmenu" href="sifilis.php">Sífilis</a></li>
          <li><a id="linkmenu" href="hep.php">Hepatites Virais</a></li>
          <li class="divider"></li>
          <li><a id="linkmenu"href="aids.php">AIDS</a></li>
          <li class="divider"></li>
          <li><a id="linkmenu" href="vigcri.php">Vigilancia Epidemiologica de Criciúma</a></li>
        </ul>
      </li>
    </ul>
    <div class="col-sm-3 col-md-3">
        <form class="navbar-form" role="search" method="post" action="busca.php">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Procurar" name="busca">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit" name="botao"> <i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form>
    </div>
   <ul class="nav navbar-nav navbar-right">
      <li><a href="contato.php">Entre em Contato</a></li>
      </ul>
      </div>
      </nav>
      

<?php

function exibe_noticiatr(){
	//print_r($conteudo['conteudo']);
	$sql = mysql_query("SELECT * FROM NOTICIAs  WHERE tag='tr' order by cod desc");
	//$resultado = mysql_fetch_array($sql);
	
	//echo $resultado['texto'];
	$i = 0;
	while($resultado = mysql_fetch_array($sql)){
	$i++;
		echo '<p><div align="justify">'.$resultado['texto']."</div> </p>";
		echo "<br/>";
	if ($resultado['foto1'] != null){
			
			//imprime as imagens
			echo '<center> <img src="editorTesteRapido/fotos_noticias/'.$resultado['foto1'].' " class="img-responsive" data-toggle="modal" data-target="#myModal'.$i.'" />';
			
			//Imprime os modais
			echo '      <div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Imagem</h4>
      </div>
      <div class="modal-body">
        <img src="editorTesteRapido/fotos_noticias/'.$resultado['foto1'].'"class="img-responsive">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
      </div>
    </div>

  </div>
</div>';
			
		}
	

	
	}
}

exibe_noticiatr();

?>
    



<footer class="rodape">
      <div class="container">
        <p class="text-muted">Prefeitura Muncipal de Criciúma</p>
          <p class="text-muted">Secratária Muncipal de Saúde de Criciúma</p>
            <p class="text-muted">Vigilancia Epidemiologica de Criciúma</p>
              <p class="text-muted">Programa de Atenção as DST´s HIV  e Aids- PAMDHA</p>
                <p class="text-muted">Telefone (048) 34458730</p>
      </div>
      
         <!-- Facebook -->
    <center> <a href="http://www.facebook.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" />
    </a>
    <!-- Google+ -->
    <a href="https://plus.google.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/google.png" alt="Google" />
    </a>
    <!-- LinkedIn -->
    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://simplesharebuttons.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/linkedin.png" alt="LinkedIn" />
    </a>
    <!-- Twitter -->
    <a href="https://twitter.com/share?url=https://simplesharebuttons.com&amp;text=Simple%20Share%20Buttons&amp;hashtags=simplesharebuttons" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" />
    </a> </center>
      
    </footer>
      



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="jsdstprot.js"> </script>
    
  </body>
</html>