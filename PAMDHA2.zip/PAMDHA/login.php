<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php 

session_start();

$login = $_POST['login'];
$senha = $_POST['senha'];
$senha = MD5($senha);

$con = mysql_connect("localhost", "root", "") or die ("Sem conexão com o servidor");
$select = mysql_select_db("pamdha") or die("Sem acesso ao DB");

$result = mysql_query("SELECT * FROM usuarios WHERE login = '$login' AND senha = '$senha'");

if(mysql_num_rows ($result) > 0 )
{
	$_SESSION['login'] = $login;
	$_SESSION['senha'] = $senha;
	header('location:gerenciadorpamdha.php');
}
else{
	unset ($_SESSION['login']);
	unset ($_SESSION['senha']);
	header('location:logininvalido.html');
	
	}

?>


</body>
</html>