

<html>
<head>
<title>Livro de PHP - Upload de m�ltiplos arquivos</title>
</head>
<body>
<h2 align="center">Upload de m�ltiplos arquivos</h2>

<?php
// elimina o limite de tempo de execu��o
set_time_limit (0);

// inclui o arquivo com as configura��es
include 'config_upload.inc';

// repete os mesmos comandos para os 5 arquivos

$arquivo = array();



for ($i=1 ; $i<=5 ; $i++)
{
	
    $id_arquivo = "arquivo".$i;
    $erro = FALSE;
	$noticia =$_POST["noticia"];
    echo $noticia,"<br>";
	 $nome_arquivo =" ";
    $nome_arquivo = $_FILES[$id_arquivo]['name'];
    $tamanho_arquivo = $_FILES[$id_arquivo]['size'];
    $arquivo_temporario = $_FILES[$id_arquivo]['tmp_name'];
    echo $nome_arquivo;
  
    if (!empty ($nome_arquivo))
	echo $nome_arquivo;
	$vetor = array ("a", "b", "c","d", "e","f","g","A","B","C","D",1,2,3,4,5,6,7,8,9,0);
	$token="";
	for($x=0;$x<=6;$x++){
		$num = rand  (1,20);
		$letra =$vetor[$num];
		$token=$token.$letra;
	}

	$arquivo[$i] = $token.$nome_arquivo;
    $nome_arquivo1= $token.$nome_arquivo;
	
    {
    	if ($sobrescrever == "nao" && file_exists("$caminho_absoluto/$nome_arquivo1"))
    	{
            $erro = TRUE;
    		echo "Arquivo $nome_arquivo j� existe.";
			
   		}

    	if (($limitar_tamanho == "sim") && ($tamanho_arquivo > $tamanho_bytes))
        {
            $erro = TRUE;
    		echo "Arquivo $nome_arquivo deve ter no m�ximo $tamanho_bytes bytes.";
   		}

    	$ext = strrchr($nome_arquivo,'.');

    	if (@$limitar_ext == "sim" && !in_array($ext,$extensoes_validas))
    	{
            $erro = TRUE;
    		echo "Extens�o do arquivo $nome_arquivo inv�lida para upload.";
   		}

    	if(!$erro && move_uploaded_file($arquivo_temporario, "$caminho_absoluto/$nome_arquivo")){
		 
    		echo "<p align=center>O upload do arquivo <b>$nome_arquivo</b> foi conclu�do com sucesso.</p>";
	}else{
    		echo "<p align=center>O arquivo $nome_arquivo n�o p�de ser copiado para o servidor.</p>";
		 }
    }
	$token ="";
	$nome_arquivo =" ";
}

$arquivo[1];
$arquivo[2];
$arquivo[3];
$arquivo[4];
$arquivo[5];




?>

</body>
</html>
