<?php
  include "funcao1.php";
  @include "config_upload.inc";
  $db=conecta1();
  $cont=1;
  $sql="select LAST_INSERT_ID(cod) from noticias";
  $rs = mysql_query($sql);
  while($campo=mysql_fetch_array($rs)){
  $cont=$campo[0];
  if($cont==0){
  $cont=1;
  }else{
  $cont=$campo[0]+1;
  }
  }
  
$texto=$_POST["texto"];
for ($i=0 ; $i<6 ; $i++)
{
 $erro = FALSE;
 $nome_arquivo=$_FILES['arquivo']['name'][$i];
 $ext=get_ext($nome_arquivo);
 if ($nome_arquivo<>""){
 $nome_arquivo="not".$cont.$i.".".$ext;
 $foto11[$i]=$nome_arquivo;
 }
 if(isset($foto11[0])){
 $foto1=$foto11[0];
 }
 if(isset($foto11[1])){
 $foto2=$foto11[1];
 }
if(isset($foto11[2])){
 $foto3=$foto11[2];
 }
 if(isset($foto11[3])){
 $foto4=$foto11[3];
 }
 if(isset($foto11[4])){
 $foto5=$foto11[4];
 }
 if(isset($foto11[5])){
 $foto6=$foto11[5];
 }
 $tamanho_arquivo = $_FILES['arquivo']['size'][$i];
 $arquivo_temporario = $_FILES['arquivo']['tmp_name'][$i];
 if (!empty ($nome_arquivo))
   {

    	if ($sobrescrever == "sim" && file_exists("$caminho_absoluto/$nome_arquivo"))

    	{

            $erro = TRUE;

    		echo "<p align=center><font color=red>Arquivo $nome_arquivo j� existe.</font>";

   		}



    	if (($limitar_tamanho == "sim") && ($tamanho_arquivo > $tamanho_bytes))

        {

            $erro = TRUE;

    		echo "<p align=center><font color=red>Arquivo $nome_arquivo deve ter no m�ximo $tamanho_bytes bytes.</font>";

   		}



    	$ext = strrchr($nome_arquivo,'.');

    	if ($limitar_ext == "sim" && !in_array($ext,$extensoes_validas))

    	{

            $erro = TRUE;

    	//	echo "<p align=center><font color=red>Extens�o do arquivo $nome_arquivo inv�lida para upload.</font>";

   		}



    	if(!$erro && move_uploaded_file($arquivo_temporario, "$caminho_absoluto/$nome_arquivo")) {

            $origem="$caminho_absoluto/$nome_arquivo";
            $destino="$caminho_absoluto/$nome_arquivo";
            echo "<p align=center>O upload do arquivo <b>$nome_arquivo</b> foi conclu�do com sucesso.</p>";
          }
    	else  {

    		echo "<p align=center>O arquivo $nome_arquivo n�o p�de ser copiado para o servidor.</p>";

    }   }

}


if(empty($foto1)){
$foto1=""; }
if(empty($foto2)){
$foto2=""; }
if(empty($foto3)){
$foto3=""; }
if(empty($foto4)){
$foto4=""; }
if(empty($foto5)){
$foto5=""; }
if(empty($foto6)){
$foto6=""; }

$insere=mysql_query("insert into noticia(cod,texto,foto1,foto2,foto3,foto4,foto5,foto6,tag) Values
('$cont','$texto','$foto1','$foto2','$foto3','$foto4','$foto5','$foto6','vigepm')");
if ($insere){
	include("cadastrook.php");

 }




