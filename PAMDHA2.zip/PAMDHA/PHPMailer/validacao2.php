<?php
include("conexaobanco.php");
require "class.PHPMailer.php";
require "class.stmp.php";

$sql = mysql_query("SELECT nome, email, senha FROM meuemail");

if (!$sql) {
echo 'Não foi possivel conectar ao banco de dados'.mysql_error();
exit;	
	
}
$row = mysql_fetch_array($sql);

$tb_nome = $row[0];
$tb_email = $row[1];
$tb_senha = $row [2];

$form_nome =$_POST ['nome'];
$form_telefone =$_POST ['telefone'];
$form_email =$_POST ['email'];
$form_mensagem =$_POST ['mensagem'];

$mail = new PHPMailer ();
$mail ->setLanguage('pt');

$host = 'smtp.live.com';
$username = $tb_email;
$password = $tb_senha;
$port = 25;
$secure = 'tls';

$from = $form_email;
$fromName = $form_nome;

$mail->IsSMTP();
$mail->Host = $host;
$mail->SMTPAuth = true;
$mail->Username = $username;
$mail->Passoword =$password;
$mail->Port = $port;
$mail->SMTPSecure = $secure;


$mail->From =$from;
$mail->FromName = $fromName;
$mail->addReplyTo($from,$fromName);


$mail->addAddress($tb_email,$tb_nome);


$mail->isHTML(true);
$mail->CharSet = 'utf-8';
$mail->WordWrap =70;

$mail->Subject = $form_nome;
$mail->Body = $form_mensagem;
$mail->AltBody = $form_mensagem;

$send = $mail->send();

if ($send)
echo "<script>window.location='..pamdha/contato.php?ret=1';</script>";
else "<script>window.location='..pamdha/contato.php?ret=2';</script>";

  



?>