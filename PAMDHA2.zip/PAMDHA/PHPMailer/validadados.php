
<?php
include("conexaobanco.php");

require "class.phpmailer.php";
require "class.smtp.php";

session_start();

$sql = mysql_query("SELECT nome, email, senha FROM meuemail");

if (!$sql) {
echo 'Não foi possivel conectar ao banco de dados'.mysql_error();
exit;	
	
}
$row = mysql_fetch_row($sql);

$tb_nome = $row[0];
$tb_email = $row[1];
$tb_senha = $row [2];

$form_nome =$_POST ['nome'];
$form_telefone =$_POST ['telefone'];
$form_email =$_POST ['email'];
$form_destino =$_POST ['destino'];
$form_mensagem =$_POST ['mensagem'];

$mail = new PHPMailer ();
$mail ->setLanguage('pt');

$host = 'smtp.gmail.com';
$username = $tb_email;
$password = $tb_senha;
$port = 587;
$secure = 'tls';

$from = $form_email;
$fromName = $form_nome;

$mail->IsSMTP();
$mail->Host = $host;
$mail->SMTPAuth = true;
$mail->Username = $username;
$mail->Password =$password;
$mail->Port = $port;
$mail->SMTPSecure = $secure;


$mail->From =$from;
$mail->FromName = $fromName;
$mail->addReplyTo($from,$fromName);


$mail->addAddress($tb_email,$tb_nome);


$mail->isHTML(true);
$mail->CharSet = 'utf-8';
$mail->WordWrap =70;

$mail->Subject = $form_destino;
//$mail->AltBody =$form_telefone;
$corpoMensagem = "Nome: " . $fromName . "<br>";
$corpoMensagem .= "Telefone: " . $form_telefone . "<br>";
$corpoMensagem .= "Email: " . $form_email . "<br>";
$corpoMensagem .= "	Mensagem: ". $form_mensagem;
$mail->Body = $corpoMensagem; 




$send = $mail->send();

if ($send){header ("location: ../enviado.php");
}else {header("location: ../naoenviado.php");

  
}

?>