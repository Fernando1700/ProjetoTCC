<?php

if(mail('fernandoppacheco@hotmail.com', 'assunto', 'Olá mundo')){
	echo "sucesso";
	
}

?>