<?php
include("conexaobanco.php");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> Resultados da Busca </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="pamdha1.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   <h4>  <center> <a href="index.php"><img class="img-responsive" title="PAMDHA" src="logopamdha.png"/> </a> </center> <h4>
    
    <nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
      
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
     <li> <a href="index.php" > PAMDHA </a>
      <li><a href="dstprot.php">Infecções Sexualmente Transmissiveis e Proteção</a></li>
      <li><a href="tr.php">Testes Rápidos</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">DST´s <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a href="hiv.php">HIV</a></li>
          <li><a href="sifilis.php">Sífilis</a></li>
          <li><a href="hep.php">Hepatites Virais</a></li>
          <li class="divider"></li>
          <li><a href="aids.php">AIDS</a></li>
          <li class="divider"></li>
          <li><a href="vigcri.php">Vigilancia Epidemiologica de Criciúma</a></li>
        </ul>
      </li>
    </ul>
    <div class="col-sm-3 col-md-3">
        <form class="navbar-form" role="search" method="post" action="busca.php">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Procurar" name="busca">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit" name="botao"> <i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form>
    </div>
   <ul class="nav navbar-nav navbar-right">
      <li><a href="contato.php">Entre em Contato</a></li>
      </ul>
      </div>
      </nav>


<?php


if (isset ($_POST['botao']));{
$busca = $_POST['busca'];

if($busca == "" or $busca==" "){
	echo 'Ops! Digite alguma coisa...';
	
}else {

$procura_palavrametade = explode (' ',$busca);
$quantidade = count($procura_palavrametade);
$procura_mostrada = array("");


for($i=0;$i<$quantidade;$i++){
$palavrafornecida = $procura_palavrametade[$i];
	
	
	$sql = mysql_query("SELECT * FROM noticias WHERE texto LIKE '%$palavrafornecida%'");
	
	
	$totaldecampos = mysql_num_rows($sql);
	if($totaldecampos == 0){
		echo 'Ah não! Nenhum resultado foi obtido... ';
	}else
	while ($trazer = mysql_fetch_array($sql)){
		$cod =$trazer['cod'];
		$texto = $trazer['texto'];
		$foto1 = $trazer['foto1'];
		
		if (!array_search($cod, $procura_mostrada)){
			$conteudo2 = str_replace($palavrafornecida,'<font color="#FFFF00">'.$palavrafornecida. '</font>',$conteudo);
			echo "
			<div class='result'>
			<c<p><strong>".$texto."</strong></p>
			</div>
			
		
		
	";
	
	} 

	}
	//array_push($procura_mostrada,$id);
	
  }
 
}
}


 
?>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>