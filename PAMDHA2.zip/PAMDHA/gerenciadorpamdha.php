<?php 

session_start(); 

echo '<center> <strong> Seja Bem Vindo ' .$_SESSION['login'].'</strong> </center>';
echo'<center> Cadastre um novo usuario e senha <a href="cadastro.php">Clique aqui</a> </center><br />';

if((!isset($_SESSION['login'])) or (!isset ($_SESSION['senha']))) 
{ 
unset($_SESSION['login']); 
unset($_SESSION['senha']); 
header('location:adm.html'); 
} 

$logado = $_SESSION['login']; 
?>

<center> <form method="post" action="logout.php"> 
<input name="sair" type="submit" id="Sair" value="Sair" /> 
</form> </center>

   


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="login.css" rel="stylesheet"/>
<title>Pagina Administrativa PAMDHA</title>
</head>


<body>

<h1> <center> Selecione uma Página para realizar a atualização: </center> </h1></br>

<strong>Para atualizar a página inicial- PAMDHA <a href="/www/pamdha/editorPamdha/editor.php"> Clique aqui </a> </br></br></strong>
<strong>Para atualizar a pagina de IST´s e Proteção. <a href="editorIST/editor.php"> Clique aqui </a> </br></br></strong>
<strong>Para atualizar a pagina de Testes Rápidos. <a href="editorTesteRapido/editor.php"> Clique aqui </a> </br></br></strong> 
<strong>Para atualizar a pagina de HIV. <a href="editorhiv/editor.php"> Clique aqui </a> </br></br></strong>
<strong>Para atualizar a página de Sifilis. <a href="editorSifilis/editor.php"> Clique aqui </a> </br></br></strong>
<strong>Para atualizar a pagina de Hepatites Virais. <a href="editorHep/editor.php"> Clique aqui </a> </br></br></strong>
<strong>Para atualizar a pagina de Aids. <a href="editorAids/editor.php" </a> Clique aqui </a> </br></br></strong>

</body>
</html>