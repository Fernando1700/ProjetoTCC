<?php 

session_start(); 

echo '<center> <strong> Seja Bem Vindo ' .$_SESSION['login'].'</strong> </center>';

if((!isset($_SESSION['login'])) or (!isset ($_SESSION['senha']))) 
{ 
unset($_SESSION['login']); 
unset($_SESSION['senha']); 
header('location:adm.html'); 
} 

$logado = $_SESSION['login']; 
?>
<center> <form method="post" action="logout.php"> 

<input name="sair" type="submit" id="Sair" value="Sair" /> 
</form> </center>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>
<title> Cadastro de Usuário e Login </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="login.css" rel="stylesheet"/>
</head>
<body>
<br />
<center> <img src="Imagens/avisoadm.jpg" /> </center>

<h1> <center> Acesso Restrito. Cadastro de Login e Senha  </center> </h1>
<center><form method="POST" action="cadloginSuperUser.php"><br />
<label>Login:</label><input type="text" name="login" id="login"><br><br />
<label>Senha:</label><input type="password" name="senha" id="senha"><br> <br />
<input type="submit" value="Cadastrar" id="cadastrar" name="cadastrar"></center> <br />
</form>
</body>
</html>
