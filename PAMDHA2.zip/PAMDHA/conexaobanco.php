<?php

$db = @mysql_connect("localhost","root","") or die ("Erro ao conectar.".mysql_error());
@mysql_select_db("pamdha",$db) or die ("Erro ao conectar  na selecao banco de dados.".mysql_error());
mysql_set_charset('utf8',$db);


$pamdhatextoindex = mysql_query("SELECT conteudo FROM busca WHERE id=1");
$conteudo = mysql_fetch_array($pamdhatextoindex);
		
$pamdhatextodstprot = mysql_query("SELECT conteudo FROM busca WHERE id=2");
$conteudo3 = mysql_fetch_array($pamdhatextodstprot);

$pamdhatextotr = mysql_query("SELECT conteudo FROM busca WHERE id=3");
$conteudo4 = mysql_fetch_array($pamdhatextotr);

$pamdhatextohiv = mysql_query("SELECT conteudo FROM busca WHERE id=4");
$conteudo5 = mysql_fetch_array($pamdhatextohiv);

$pamdhatextosifilis = mysql_query("SELECT conteudo FROM busca WHERE id=5");
$conteudo6 = mysql_fetch_array($pamdhatextosifilis);

$pamdhatextohep = mysql_query("SELECT conteudo FROM busca WHERE id=6");
$conteudo7 = mysql_fetch_array($pamdhatextohep);

$pamdhatextoaids = mysql_query("SELECT conteudo FROM busca WHERE id=7");
$conteudo8 = mysql_fetch_array($pamdhatextoaids);

$pamdhatextovig = mysql_query("SELECT conteudo FROM busca WHERE id=8");
$conteudo9 = mysql_fetch_array($pamdhatextovig);




	




?>