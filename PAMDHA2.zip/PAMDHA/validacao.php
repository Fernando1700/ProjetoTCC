<?php

$para = "fernandozeus00@gmail.com";
$titulo = "Conato pelo Site";
$nome = $_REQUEST ['nome'];
$telefone = $_REQUEST ['telefone'];
$email = $_REQUEST ['email'];
$assunto = $_REQUEST ['assunto'];


$corpo = "<strong> Mensagem do Contato pelo Site </strong><br> <br>";
$corpo.="<strong> Nome:  </strong> $nome ";
$corpo.="<br><strong> Telefone:  </strong> $telefone ";
$corpo.="<br><strong> Email:  </strong> $email ";
$corpo.="<br><strong> Assunto:  </strong> $assunto ";

$header ="Content-type: text/html; charset= utf-8\n";
$header .=" From: $email  Reply-to : $email\n";


@mail($para,$assunto,$corpo, $header);
header("location:index.php?assunto=enviado");




?>