<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> PAMDHA - Programa de Atenção Municipal às DST/HIV e AIDS de Críciúma/SC</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="pamdha1.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   <h4> <center> <font color="#000000"> Programa de Atenção Municipal às DST/HIV e AIDS de Críciúma/SC </font> </center> </font> <h4>
    
    <nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
      
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
     <li class="active"> <a href="index.php" > PAMDHA </a>
      <li><a href="dstprot.php">Doenças Sexualmente Transmissiveis e Proteção</a></li>
      <li><a href="tr.php">Testes Rápidos</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">DST´s <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a href="hiv.php">HIV</a></li>
          <li><a href="sifilis.php">Sífilis</a></li>
          <li><a href="hep.php">Hepatites Virais</a></li>
          <li class="divider"></li>
          <li><a href="aids.php">AIDS</a></li>
          <li class="divider"></li>
          <li><a href="#">Vigilancia Epidemiologica de Criciúma</a></li>
        </ul>
      </li>
    </ul>
    <div class="col-sm-3 col-md-3">
        <form class="navbar-form" role="search">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Procurar" name="q">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form>
    </div>
   <ul class="nav navbar-nav navbar-right">
      <li><a href="contato.php">Entre em Contato</a></li>
      </ul>
      </div>
      </nav>
      <div id="Carousel" class="carousel slide carousel-fade col-lg-12 col-offset-0">
        <ol class="carousel-indicators">
            <li data-target="Carousel" data-slide-to="0" class="active"></li>
            <li data-target="Carousel" data-slide-to="1"></li>
            <li data-target="Carousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner">
            <div class="item active">
                <img src="dst.jpg" class="img-responsive">
            </div>
           <div class="item">
             <img src="DST2.jpg" class="img-responsive">
            </div>
           <div class="item">
             <img src="dst-prevencao.jpg" class="img-responsive">
            </div> 
        </div> 

        <a class="left carousel-control" href="#Carousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
        <a class="right carousel-control" href="#Carousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
        </div>
        </nav>
    
    <!-- Aqui começa o conteudo -->
<div class="wrapper" role="main">
	<div class="container">
		<div class="row">
			<div id="principal" class="col-lg-12 col-offset-0">
            
       
            
O Programa de atenção Municipal de DST/HIV e AIDS de Criciúma Santa Catarina (PAMDHA) marcou seu inicio com 
registro no Ministério da Saúde em 1996. A equipe até então era composta pela coordenação do Técnico de Enfermagem-Edson Black, por 02 técnicos, 02 médicos, 01 assistentes social e um psicólogo. Já no ano de 1999 marcou a contratação de um médico infectologista. Em 2001, o serviço ficou sobre a responsabilidade do Médico José Artur Moura, Entre 2002 a 2005 o Programa esteve sobre a Coordenação da Psicóloga Rita Guimarães que no ano de 2004, juntamente com a equipe inauguraram a Unidade de Saúde de Atendimento Multiprofissional Especializado (AME), localizava-se à rua São José , 414- Centro de Criciúma e funcionava até março de 2008 com quatro programas : Tuberculose, Hanseníase , Hepatites Virais e DST/HIV e AIDS.
            <Center>  <img src="fonts/equipe-HU-DST-Aids-na-mira-da-prevenção-Foto-Divulgação.jpg" class="img-responsive"> </Center>
             
Em 2005 o Programa esteve sobre a coordenação da A.S Suzana Vaz até meados de 2008, nesse período somou mais uma psicóloga e assistente social para CTA(Centro de Testagem e Aconselhamento). Em meados de 2008, o Programa contou com a continuidade da equipe ingressando uma nutricionista, coordenação da Psicóloga Fabiana Bardini, até o ano de 2010 permanecendo até meados de 2016 quando entra na Coordenação Andréia Sharon e segue até os dias atuais. Atualmente o PAMDHA esta localizado na Rua Maria Argente Filho, Bairro Santo Antonio.
            
         <center>  <img src="images.jpg" class="img-responsive" class="col-lg-12 col-offset-0"> </center>
            
O PAMDHA é um dos setores vinculados a vigilância epidemiológica de Criciúma, e referência na cidade em tratamento de DST´s, HIV e AIDS. No espaço físico do Programa adentram cerca de 1500 por mês. Existem, atualmente, no Programa atendimento médico especializado, com médicos infectologistas, infecto-pediatra, gineco-obstretrícia para as gestantes com HIV positivo e ainda oferece atendimento especializado com Enfermeiras, Serviço Social , Psicóloga e Farmácia para a retirada dos medicamentos.
Dentro do Programa existe o CTA com atendimentos em período integral, com realização de Teste Rápidos e atende a todos os interessados realizando orientações e formas de prevenção as DST´S, além de trabalhos educativos realizados em diversos pontos da cidade de Criciúma.

<center> <img src="IMG_3285.jpg" class="img-responsive" class="col-lg-12 col-offset-0"> </center>
	 	
            
		</div>
	</div>
</div> <!-- Fim do conteudo -->    
    
 
    	
        
</div>
</li>
<footer class="rodape">
      <div class="container">
        <p class="text-muted">Prefeitura Muncipal de Criciúma</p>
          <p class="text-muted">Secratária Muncipal de Saúde de Criciúma</p>
            <p class="text-muted">Vigilancia Epidemiologica de Criciúma</p>
              <p class="text-muted">Programa de Atenção as DST´s HIV  e Aids- PAMDHA</p>
                <p class="text-muted">Telefone (048) 34458730</p>
                
                 <!-- Facebook -->
    <center> <a href="http://www.facebook.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" />
    </a>
    <!-- Google+ -->
    <a href="https://plus.google.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/google.png" alt="Google" />
    </a>
    <!-- LinkedIn -->
    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://simplesharebuttons.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/linkedin.png" alt="LinkedIn" />
    </a>
    <!-- Twitter -->
    <a href="https://twitter.com/share?url=https://simplesharebuttons.com&amp;text=Simple%20Share%20Buttons&amp;hashtags=simplesharebuttons" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" />
    </a> </center>
                

    </footer>
      



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>