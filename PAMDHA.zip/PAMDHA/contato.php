<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> PAMDHA - Programa de Atenção Municipal às DST/HIV e AIDS de Críciúma/SC</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="pamdhacont.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

<body>
<form action="validacao.php" method="post";
<section id="contact" class="content-section text-center">
        <div class="contact-section">
            <div class="container">
              <h2>Contato PAMDHA</h2>
              <p> Está com alguma dúvida, precisa de ajuda? Estamos, aqui, para lhe atender. Envie sua mensagem para nós</p>
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <form class="form-horizontal">
                    <div class="form-group">
                      <label for="Nome2">Nome Completo: </label>
                      <input type="text" class="form-control" id="Nome2" placeholder="João da Silva Oliveira" name="nome" required>
                    </div>
                    <div class="form-group">
                      <label for="telefone">Telefone:</label>
                      <input type="tel" class="form-control" id="Telefone2" placeholder="(048) 34458730 " name="telefone"required >
	
                      </div>
                    <div class="form-group">
                      <label for="email2">Email:</label>
                      <input type="email" class="form-control" id="email2" placeholder="meuemail@gmail.com" name="email" required>
                    </div>
                    <div class="form-group ">
                      <label for="mensagem2">Qual a sua mensagem:</label>
                     <textarea  class="form-control" placeholder=""
                     name="mensagem" required></textarea> 
                    </div>
                    <button type="submit" class="btn btn-default">Enviar Mensagem</button>
                  </form>
				  
				  
                  <hr>
                      <!-- Facebook -->
    <center> <a href="http://www.facebook.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" />
    </a>
    <!-- Google+ -->
    <a href="https://plus.google.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/google.png" alt="Google" />
    </a>
    <!-- LinkedIn -->
    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://simplesharebuttons.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/linkedin.png" alt="LinkedIn" />
    </a>
    <!-- Twitter -->
    <a href="https://twitter.com/share?url=https://simplesharebuttons.com&amp;text=Simple%20Share%20Buttons&amp;hashtags=simplesharebuttons" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" />
    </a> </center>
                    
                  </ul>
                </div>
              </div>
            </div>
        </div>
      </section>
</form>
</body>
</html>