<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> PAMDHA - Programa de Atenção Municipal às DST/HIV e AIDS de Críciúma/SC</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="pamdha1.css" rel="stylesheet">
    <link rel="stylesheet" href="/js/vegas/vegas.min.css">
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   <h4> <center> <font color="#000000"> Programa de Atenção Municipal às DST/HIV e AIDS de Críciúma/SC </font> </center> </font> <h4>
    
    <nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
      
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
     <li> <a href="index.php" > PAMDHA </a>
      <li><a href="dstprot.php">Infecções Sexualmente Transmissiveis e Proteção</a></li>
      <li class="active"><a href="tr.php">Testes Rápidos</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">DST´s <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a href="hiv.php">HIV</a></li>
          <li><a href="sifilis.php">Sífilis</a></li>
          <li><a href="hep.php">Hepatites Virais</a></li>
          <li class="divider"></li>
          <li><a href="aids.php">AIDS</a></li>
          <li class="divider"></li>
          <li><a href="#">Vigilancia Epidemiologica de Criciúma</a></li>
        </ul>
      </li>
    </ul>
    <div class="col-sm-3 col-md-3">
        <form class="navbar-form" role="search">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Procurar" name="q">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form>
    </div>
   <ul class="nav navbar-nav navbar-right">
      <li><a href="contato.php">Entre em Contato</a></li>
      </ul>
      </div>
      </nav>
      

<h1> <center> O que são Testes Rápidos</center> </h1>
<h4> Os testes rápidos são ensaios imunoenzimáticos simples que podem ser realizados em até 30 minutos. Existem vários formatos de testes rápidos e os utilizados mais frequentemente são: dispositivos (ou tiras) de imunocromatografia (ou fluxo lateral), imunocromatografia de dupla migração (DPP) e dispositivos de imunoconcentração e fase sólida. Desde março de 2006, o Departamento de DST, Aids e Hepatites Virais vem implantando o teste rápido como diagnóstico da infecção pelo HIV no Brasil. Esta metodologia é utilizada no mundo inteiro e traz vantagens significativas quanto ao método laboratorial, pois são de simples realização, dispensando a atuação de profissionais especializados e de equipamentos de laboratório, permitindo o conhecimento dos resultados e assistência imediata aos pacientes. A Portaria nº 29 de 17 de dezembro de 2013 normatiza o algoritmo para o diagnóstico da infecção pelo HIV utilizando exclusivamente testes rápidos – Fluxogramas 1 e 2 desta Portaria. A elaboração desta normativa está fundamentada na realização dos estudos de validação dos testes rápidos e de extensa discussão com diversos segmentos da comunidade científica e instituições governamentais. O algoritmo preconizado no país permite que o diagnóstico da infecção pelo HIV seja realizado sem que haja necessidade do uso de quaisquer outros exames laboratoriais para confirmação do resultado. A utilização desta metodologia no Brasil está diretamente associada ao aumento do acesso ao diagnóstico da infecção pelo HIV, principalmente em segmentos populacionais prioritários, como: gestantes, parturientes, pacientes com sintomas da Aids, populações vulneráveis, populações flutuantes, moradores de rua, dentre outros. Os serviços de saúde que terão esta tecnologia à disposição serão aqueles cujos estados julgarem necessários, respeitando as especificidades locais de cada realidade.</h4>
</li>




<!-- Trigger the modal with a butto --> 
<center> <img src="reagente_hiv_testerapido.jpg" width="200" height="200"  data-toggle="modal" data-target="#myModal">
 </center>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Testes Rapidos</h4>
      </div>
      <div class="modal-body">
       <center> <img src="reagente_hiv_testerapido.jpg"> </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
      </div>
    </div>

  </div>
</div>
</div>
<center> <h1> Saiba mais sobre os Testes Rápidos! Assista ao vídeo</h1> </center>
     <div class="col-md-12">
<iframe class="col-sm-12" height="333" frameborder="0" wmode="Opaque" allowfullscreen="" src="https://www.youtube.com/embed/qhwJWfD85Tk?wmode=transparent"> </iframe>
</div>

<footer class="rodape">
      <div class="container">
        <p class="text-muted">Prefeitura Muncipal de Criciúma</p>
          <p class="text-muted">Secratária Muncipal de Saúde de Criciúma</p>
            <p class="text-muted">Vigilancia Epidemiologica de Criciúma</p>
              <p class="text-muted">Programa de Atenção as DST´s HIV  e Aids- PAMDHA</p>
                <p class="text-muted">Telefone (048) 34458730</p>
      </div>
      
         <!-- Facebook -->
    <center> <a href="http://www.facebook.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" />
    </a>
    <!-- Google+ -->
    <a href="https://plus.google.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/google.png" alt="Google" />
    </a>
    <!-- LinkedIn -->
    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://simplesharebuttons.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/linkedin.png" alt="LinkedIn" />
    </a>
    <!-- Twitter -->
    <a href="https://twitter.com/share?url=https://simplesharebuttons.com&amp;text=Simple%20Share%20Buttons&amp;hashtags=simplesharebuttons" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" />
    </a> </center>
      
    </footer>
      



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="jsdstprot.js"> </script>
    
  </body>
</html>