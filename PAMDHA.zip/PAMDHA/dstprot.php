<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title> PAMDHA - Programa de Atenção Municipal às DST/HIV e AIDS de Críciúma/SC</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <LINK href="pamdha1.css" rel="stylesheet">
    <link rel="stylesheet" href="/js/vegas/vegas.min.css">
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
   <h4> <center> <font color="#000000"> Programa de Atenção Municipal às DST/HIV e AIDS de Críciúma/SC </font> </center> </font> <h4>
    
    <nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
      
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav">
     <li> <a href="index.php" > PAMDHA </a>
      <li class="active"><a href="dstprot.php">Infecções Sexualmente Transmissiveis e Proteção</a></li>
      <li><a href="tr.php">Testes Rápidos</a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">DST´s <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a href="hiv.php">HIV</a></li>
          <li><a href="sifilis.php">Sífilis</a></li>
          <li><a href="hep.php">Hepatites Virais</a></li>
          <li class="divider"></li>
          <li><a href="aids.php">AIDS</a></li>
          <li class="divider"></li>
          <li><a href="#">Vigilancia Epidemiologica de Criciúma</a></li>
        </ul>
      </li>
    </ul>
    <div class="col-sm-3 col-md-3">
        <form class="navbar-form" role="search">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Procurar" name="q">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form>
    </div>
   <ul class="nav navbar-nav navbar-right">
      <li><a href="contato.php">Entre em Contato</a></li>
      </ul>
      </div>
      </nav>
      <center> <h1> Saiba mais sobre as DST´S/IST´s! Assista ao Vídeo</h1> </center>
     <div class="col-md-12">
<iframe class="col-sm-12" height="333" frameborder="0" wmode="Opaque" allowfullscreen="" src="https://www.youtube.com/embed/BgD97Ycak1E?wmode=transparent"> </iframe>
</div>

<h1> <center> O que são IST ? </center> </h1>
<h4> As Infecções Sexualmente Transmissíveis (IST) são causadas por vírus, bactérias ou outros microrganismos.
São transmitidas, principalmente, por meio do contato sexual (oral, vaginal, anal) sem o uso de camisinha masculina ou feminina com uma pessoa que esteja infectada. A transmissão de uma IST pode acontecer, ainda, da mãe para a criança durante a gestação, o parto ou a amamentação.
O tratamento das pessoas com IST melhora a qualidade de vida e interrompe a cadeia de transmissão dessas infecções. O atendimento e o tratamento são gratuitos nos serviços de saúde do SUS.
A terminologia Infecções Sexualmente Transmissíveis (IST) passa a ser adotada em substituição à expressão Doenças Sexualmente Transmissíveis (DST), porque destaca a possibilidade de uma pessoa ter e transmitir uma infecção, mesmo sem sinais e sintomas.</h4>
</li>




<!-- Trigger the modal with a butto --> 
<center> <img src="ds1.jpg" width="200" height="200"  data-toggle="modal" data-target="#myModal">
<img src="dst2.jpg" width="200" height="200"  data-toggle="modal" data-target="#myModal1">
<img src="dst3.jpg" width="200" height="200"  data-toggle="modal" data-target="#myModal2"> </center>


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Camisinha</h4>
      </div>
      <div class="modal-body">
        <img src="ds1.jpg">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
      </div>
    </div>

  </div>
</div>



<div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">DST</h4>
      </div>
      <div class="modal-body">
        <center> <img src="DST2.jpg" width="400" height="400"> </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
      </div>
    </div>

  </div>
</div>
</div>

<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Gravidez</h4>
      </div>
      <div class="modal-body">
      <center>  <img src="DST3.jpg" width="400" height="400"> </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
      </div>
    </div>

  </div>
</div>
</div> 





<h1> <center>Como é a prevenção das IST? </center> </h1>

<h4>O uso da camisinha (masculina ou feminina) em todas as relações sexuais (oral, anal e vaginal) é o método mais eficaz para evitar a transmissão das IST, HIV/aids e hepatites virais B e C.  Serve também para evitar a gravidez.
A camisinha masculina ou feminina pode ser retirada gratuitamente nas unidades de saúde.
Quem tem relação sexual desprotegida pode contrair uma IST. Não importa idade, estado civil, classe social, identidade de gênero, orientação sexual, credo ou religião. A pessoa pode estar aparentemente saudável, mas pode estar infectada por um IST.
A prevenção combinada abrange o uso da camisinha masculina ou feminina, ações de prevenção, diagnóstico e tratamento das IST, testagem para HIV, sífilis e hepatites virais B e C, profilaxia pós-exposição ao HIV, imunização para HPV e hepatite B, prevenção da transmissão vertical de HIV, sífilis e hepatite B, tratamento antirretroviral para todas as PVHA, redução de danos, entre outros.</h4>
</li>

</div>

<footer class="rodape">
      <div class="container">
        <p class="text-muted">Prefeitura Muncipal de Criciúma</p>
          <p class="text-muted">Secratária Muncipal de Saúde de Criciúma</p>
            <p class="text-muted">Vigilancia Epidemiologica de Criciúma</p>
              <p class="text-muted">Programa de Atenção as DST´s HIV  e Aids- PAMDHA</p>
                <p class="text-muted">Telefone (048) 34458730</p>
      </div>
         <!-- Facebook -->
    <center> <a href="http://www.facebook.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/facebook.png" alt="Facebook" />
    </a>
    <!-- Google+ -->
    <a href="https://plus.google.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/google.png" alt="Google" />
    </a>
    <!-- LinkedIn -->
    <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=https://simplesharebuttons.com" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/linkedin.png" alt="LinkedIn" />
    </a>
    <!-- Twitter -->
    <a href="https://twitter.com/share?url=https://simplesharebuttons.com&amp;text=Simple%20Share%20Buttons&amp;hashtags=simplesharebuttons" target="_blank">
        <img src="https://simplesharebuttons.com/images/somacro/twitter.png" alt="Twitter" />
    </a> </center>
    </footer>
      



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="jsdstprot.js"> </script>
    
  </body>
</html>